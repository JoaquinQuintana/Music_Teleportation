#!/bin/bash
source venv/bin/activate
export FLASK_APP=Monkey.py
export FLASK_ENV=development